# Cat Mouse Game!
# ! (http://bestanimations.com/Animals/Mammals/animated-mouse-gif.gif)

Github Pages: https://pprosper.github.io/CatMouseGame/
--------

### Objctive:

You are the cat and you have to catch as many mice as possible, by clicking, in the given amount time, 30 seconds.

### MVP:

Moving mouse can be clicked, score will incrament and mouse will disappear.
A timer will count down from 30 seconds after which a window alert dispay "time is up" and score will be shown.

### Future Goal:

To make this a typing game for children. With further improvements player will be able to catch mice by typing out letters displayed on each mouse.
When each key is pressed, the cat will activate and catch specified mouse. Timer will run througout the game and timeout alert will display across the screen.


### Wirefram:

#! (https://drive.google.com/open?id=0BxBIGqCmcptLNlZ3Qjc4TTJCZ1MwOUNKWG9Ld1dHVnhsWXJj)
Script: Jquery

Methods using: .Click, .Css, .Clone, .html, .animate, Math.floor, Math.random, Math.abs, Math.ceil

Functions: Class, setTimeOut, Animate, speedCalculator


### MVP Map:

#! (https://drive.google.com/open?id=0BxBIGqCmcptLaUlycjByc09adGVVMTVybzhna0c5R3k2MlFn)

1. Creat default state: image of mouse on page with Score and Timer displays.

2. Make mouse move.

3. Creat function to make mouse disapper on click.

4. Get score to incrament by 1 point when mouse disappears.

5. Set timer to countdown.

6. Create timeout alert with message and score count.


### Challenges:

1. Creating a class for mouse that includes the finction for dissapear and score and will properly incrament score.

2. Get alert to pull score total from inner html and display with message.

2.  Creat a break so that after alert "ok" is clicked the game.

3. Creating a rest capability so that game can be played again.
